#pragma once

class Quaternion {
   public:
    float x, y, z, w;
};
