#pragma once

class CSource2Client {
   public:
    static CSource2Client* Get();
};
