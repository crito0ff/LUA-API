#pragma once

class CCSGOInput {
   public:
    static CCSGOInput* Get();
};
