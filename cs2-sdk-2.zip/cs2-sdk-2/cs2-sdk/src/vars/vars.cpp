#include "pch.hpp"

#include <vars/vars.hpp>

Vars_t g_Vars;
