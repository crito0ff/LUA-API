﻿
namespace CounterStrike2GSI.EventMessages
{
    public interface BaseEvent
    {
    }
}
