﻿
namespace CounterStrike2GSI.EventMessages
{
    public class CS2GameEvent : BaseEvent
    {
        public CS2GameEvent() : base()
        {
        }
    }
}
